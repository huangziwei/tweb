from setuptools import setup

setup(
	name='tweb',
	version='0.1',
	scripts=['tweb']
)